%load('Standish_FULL_FC_Try1_forplotting')

%load('Standish_FULL_FC_Try2_flexFo')
%load('Fixed_FlexFo_KD29')
%Fixed_ForceFo_KD29_FC
%  1:27 ob amag1
% %                28:125 ob amag2
% %                126:155 JM
% %                156:207 NG
% %                208:493 Ortho

%%
segments2average = [1 27
    28 125
    126 155 
    156 207
    208 493];
averageresults=[];
stdevresults=[]; 
bothdata = [Results2CLIP]; 

%               for lkmm = 1:size(segments2average,1)
%                   clear subsample
% 
%                  subsample= [bothdata(segments2average(lkmm,1):segments2average(lkmm,2),:)  ]; 
%                 numdatapts(lkmm) =  size(subsample,1); 
%  
%                 
%                 averageresults(lkmm,:) = mean(subsample,1); 
%                 stdevresults(lkmm,:) = std(subsample,1);
%       
%               end
%         
% %PTcalc_labels_stdev = {}; 
% resultstableNRMSD=[]; 
%                 for lkmm = 1:size(averageresults,2)
%                    
%                     resultstableNRMSD = [ resultstableNRMSD averageresults(:,(lkmm))  stdevresults(:,(lkmm)) ];
%                     %PTcalc_labels_stdev = {PTcalc_labels_stdev, PTcalc_labels{lkmm},   '1sig' };
%                 end   
%                 
% 
% resultstableNRMSD(6,:) = mean(resultstableNRMSD(1:5,:)); 


              for lkmm = 1:size(segments2average,1)
                  clear subsample

                 subsample= [bothdata(segments2average(lkmm,1):segments2average(lkmm,2),:)  ]; 
                numdatapts(lkmm) =  size(subsample,1); 
 
                
                averageresults(lkmm,:) = mean(subsample,1); 
                stdevresults(lkmm,:) = std(subsample,1);
      
              end
        
%PTcalc_labels_stdev = {}; 
resultstableNRMSD=[]; 
                for lkmm = 1:size(averageresults,2)
                   
                    resultstableNRMSD = [ resultstableNRMSD averageresults(:,(lkmm))  stdevresults(:,(lkmm)) ];
                    %PTcalc_labels_stdev = {PTcalc_labels_stdev, PTcalc_labels{lkmm},   '1sig' };
                end   
                

resultstableNRMSD(6,:) = mean(resultstableNRMSD(1:5,:)); 