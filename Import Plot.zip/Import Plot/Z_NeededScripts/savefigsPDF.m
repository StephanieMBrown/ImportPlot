function ret = savefigsPDF(addedNameText,subfolder)
% This function allows you to quickly save all currently open figures with
% a custom filename for each in multiple formats.  To use the function
% simply call savefigs with no arguments, then follow the prompts
%
% Upon execution this function will one-by-one bring each currently open
% figure to the foreground.  Then it will supply a text prompt in the main
% console window asking you for a filename.  It will save that figure to
% that filename in the .fig, .emf, .png, and .pdf formats.
%
% The formats that it saves in can be changed by commenting out or adding
% lines below.
%
% Copyright 2010 Matthew Guidry
% matt.guidry ATT gmail DOTT com  (Email reformatted for anti-spam)

hfigs = get(0, 'children');                %Get list of figures

for m = 1:length(hfigs)
    hfigs(m);
    figure(hfigs(m))  ;                              %Bring Figure to foreground
    %filename = input('Filename? (0 to skip)\n', 's')%Prompt user
    
    filename = get(gcf,'name');
    if isempty(filename)==1
        filename=sprintf('%d',m);
    end
    
    %     if strcmp(filename, '0')                        %Skip figure when user types 0
    %         continue
    %     else
    % saveas(hfigs(m), [filename '.jpg']) %Matlab .FIG file
    %         saveas(hfigs(m), [filename '.emf']) %Windows Enhanced Meta-File (best for powerpoints)
    %         saveas(hfigs(m), [filename '.png']) %Standard PNG graphics file (best for web)
    
    %eval(['print -depsc2 ' filename])   %Enhanced Postscript (Level 2 color) (Best for LaTeX documents)
    %print('-depsc2',filename)
    
    
    set(gcf,'renderer','Painters')
    set(gcf,'paperpositionmode','auto')
    %         if nargin > 1
    %         mkdir(subfolder)
    %             if isempty(addedNameText) == 0
    %             print(gcf,'-depsc2','-loose',[pwd '/' subfolder '/Fig_' filename '_' addedNameText '.pdf'])
    %             else
    %             print(gcf,'-depsc2','-loose',[pwd '/' subfolder '/Fig_' filename '.pdf'])
    %             end
    %         else if nargin > 0
    %         print(gcf,'-depsc2','-loose',['Fig_' filename '_' addedNameText '.pdf']);
    %         else
    %          print(gcf,'-depsc2','-loose',['Fig_' filename '.pdf']);
    %             end
    %         end
    
    h=gcf;
    set(h,'Units','Inches');
    pos = get(h,'Position');
    set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
    %print(h,'filename','-dpdf','-r0')
    
    
    if nargin > 1
        mkdir(subfolder)
        if isempty(addedNameText) == 0
            print(h,'-dpdf','-bestfit', [pwd '/' subfolder '/Fig_' filename '_' addedNameText '.pdf']);
        else
            print(h,'-dpdf','-bestfit',[pwd '/' subfolder '/Fig_' filename '.pdf']);
        end
    else if nargin > 0
            print(h,'-dpdf','-bestfit',['Fig_' filename '_' addedNameText '.pdf']);
        else
            print(h,'-dpdf','-bestfit',['Fig_' filename '.pdf']);
        end
    end
    
    
    
end
end