
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Step 1: import the data from the spreadsheet, simultaneously normalize and calculate new parameters (such as Mg#).
load('PUM') % Loads trace element source, if you want to change it, change it here!
TraceElements4Normalization_PUM = Sources_Trace;


Labels2Plot = [];


targetStrings_Majors = {'T(C)', 'P(kbars)','SiO2','TiO2','Al2O3', 'Cr2O3','FeO','MnO','MgO','CaO','Na2O','K2O','P2O5','NiO','H2O'};

ElementRatios= {'Th' 'U'; 'Lu' 'Hf'; 'Sm' 'Nd'; 'Lu' 'Sc'; 'Hf' 'Nd'; 'La' 'Sm'; 'Rb' 'Sr'; 'Eu' 'Sm'; 'Eu' 'Gd'; 'Nd' 'Zr'; 'Sm' 'Yb';...
    'Zr' 'Y'; 'Nb' 'Y'; 'Gd' 'Yb';  'Zr' 'Yb'; 'Zr' 'Hf'; 'Nb' 'Ta'; 'Ba' 'La'; 'Ba' 'Pb'; 'U' 'Pb'; 'Eu' 'Eu'; 'K' 'U'}; 

%targetStrings_Isotopes = {'87Sr/86Sr'	'143Nd/144Nd'	'206Pb/204Pb'	'207Pb/204Pb'	'208Pb/204Pb'	'176Hf/177Hf' '230Th/238U' '226Ra/230Th'};

targetStrings_Isotopes = {'SR87_SR86'	'ND143_ND144'	'PB206_PB204'	'PB207_PB204'	'PB208_PB204'	'HF176_HF177' 'TH230_U238_ACTIVITY' 'TH230_TH232_ACTIVITY' 'U238_TH232_ACTIVITY' 'RA226_TH230_ACTIVITY'};
%second option is for earthchem label format, first is for gale label
%format

[xlsNumbers, xlsText,xlsRAW] = xlsread('Ds_RevPet', 'TraceElementOrder');
[ElementRow,ElementColumn]= find(strcmp(xlsRAW,'Elements')==1);
[LastElementRow,LastElementColumn]= find(strcmp(xlsRAW,'LastElement')==1);
% Matrix with element labels
targetStrings_Trace = xlsRAW(ElementRow+1:LastElementRow-1, ElementColumn)';
%get element info
ElementsInfo = (xlsRAW(ElementRow+1:LastElementRow-1,ElementColumn+1));
i1 = cellfun(@ischar,ElementsInfo);
sz = cellfun('size',ElementsInfo(~i1),2);
ElementsInfo(i1) = {nan(1,sz(1))};
ElementsInfo = cell2mat(ElementsInfo)';

%gets compositions to normalize by
xlsRAW_strings=cellfun(@num2str,xlsRAW,'un',0);


%%%%%%%%%%%%%%%%% IMPORT SOURCES Defunct, now import in "Z_NeededDatasets"
% % % % % % For multiple
% % % % % %[DRow,DColumn]= find(~cellfun(@isempty,regexp(xlsRAW_strings,'PUM')) ==1);
% % % % % 
% % % % % %For One
% % % % % [DRow,DColumn]= find(ismember(xlsRAW_strings,'PUM'));
% % % % % TraceElements4Normalization_Labels = (xlsRAW(unique(DRow+1),DColumn));
% % % % % TraceElements4Normalization = (xlsRAW(ElementRow+1:LastElementRow-1,DColumn));
% % % % % 
% % % % % %fixes the NaN issue
% % % % % i1 = cellfun(@ischar,TraceElements4Normalization);
% % % % % sz = cellfun('size',TraceElements4Normalization(~i1),2);
% % % % % TraceElements4Normalization(i1) = {nan(1,sz(1))};
% % % % % TraceElements4Normalization = cell2mat(TraceElements4Normalization)';
% % % % % 
% % % % % %TraceElements4Normalization_PUM = TraceElements4Normalization(3,:); 
% % % % % TraceElements4Normalization_PUM = TraceElements4Normalization; 
% % % % % % LOADS trace element composition to normalize by, default is PUM
% % % % % normalizationColumn=1;
% % % % % DataRatios_PUM = DataRatios_TraceElements4Normalization;
% % % % % TraceElements4Normalization_Labels = {'PUM'};
% % % % % normalizationLabel= 'PUM';




%%%%%%%%%%%%%%%%% 

    
    
clear DataRatios
for gg = 1:size(ElementRatios,1)
    for ggg = 1:size(ElementRatios,2)
%         %for major and trace element matricies:
%         ElementRatiosIndex(gg,ggg) =  find(strcmp(targetStrings_Trace_all,ElementRatios(gg,ggg)));
        %for trace element only matricies:
        ElementRatiosIndex(gg,ggg) =  find(strcmp(targetStrings_Trace,ElementRatios(gg,ggg)));
    end
end


for kk = 1:size(ElementRatios,1)
    RatioLabels{kk}=sprintf('%s/%s',ElementRatios{kk,1}, ElementRatios{kk,2});
end


targetElements ={ 'SiO2'	'TiO2' 'Al2O3'	'Cr2O3'  'FeO'	'MnO'	'MgO'	'CaO'    'Na2O'	'K2O' 'P2O5' 'Fe2O3'};
[A,targetStrings_Majors_Tormey_Indicies] = ismember(targetElements, targetStrings_Majors);


Elements = {'T(C)' 'P(kbars)' ...
    'SiO2'	'TiO2'	  'Al2O3' 'Cr2O3'	  'FeO'	  'MnO'	  'MgO'	  'CaO' 'Na2O'   'K2O' 'P2O5' 'NiO' 'H2O' 'total'...
    'Mg#' 'NaK#' 'CaO/Al2O3 wt%' 'CaO/Al2O3 moles' 'Na2O/FeO' 'K2O/TiO2' '1-Mg#' 'Qtz' 'Plag' 'Oliv' 'Cpx' 'Ox' 'Or' 'Ap'};

[A,ElementIndicies4Target_Sum] = ismember(Elements, targetStrings_Majors);


runningTrace=[]; 
runningMajors=[]; 
runningLabels=[]; 
runningTormey=[]; 


runningColors_FILL=[]; 
runningColors_LINE=[]; 

runningLATLONG=[];
runningTabNames=[]; 
runningIsotopes=[];
runningTraceRatios=[];
runningMarkers=[];
runningRegions =[]; 
runningSamples =[]; 
runningVariableNames=[]; 
runningDataNames = []; 


runningINFO=[]; 
runningPHASES=[]; 
runningF=[]; 
runningEXPT=[]; 
runningTYPE=[]; 
runningSizes=[]; 
runningMajors_Unnorm=[]; 
runningReferences=[]; 
runningDepth=[]; 
runningSprRate=[]; 

for i=1:size(TabName,2)   
    %reads the names off sheets in a tab and stores them as variables
    %reorderElements_Rows(SpreadsheetName, 'Brannon1984', 'PlotOn', targetStrings_Majors,'FirstMajor','LastMajor',column2unnormalize ); 
    column2unnormalize=[]; 
  

        [MajorElements, Major_Labels, Major_Colors_Fill,Major_Colors_Line, Lat,Long,Regions, Markers,Samples,Info,Phases,F,Expt,Type,Sizes,...
        References,DEPTH,SPREADINGRATE] = reorderElements_Rows(SpreadsheetName, TabName{i}, DesiredDataName{i}, targetStrings_Majors,'FirstMajor','LastMajor'); 
%str2double(SPREADINGRATE)

            %Make empty cells for optional headings that were not
            %specified
            OptionalHeadings = {'Lat','Long','Samples','Info','Phases','F','Expt','Type','References','DEPTH','SPREADINGRATE'};
            OptionalHeadingsNumbers = {'Lat','Long','DEPTH','SPREADINGRATE'};
            

            %%
            for hgp = 1:size(OptionalHeadings,2)
                if isempty(eval(OptionalHeadings{hgp}))==1
                    padNAN = cell(size(MajorElements,1),1);
             
                    %save nans for running matrix
                    assignin('base',OptionalHeadings{hgp},padNAN)
                else
                    
             
                    %save as named variable 
                        if ismember(OptionalHeadings{hgp},OptionalHeadingsNumbers)==1
                          
                           
                  
                            assignin('base', sprintf('%s_%s',TabName{i},OptionalHeadings{hgp}),str2double(eval(OptionalHeadings{hgp})))
                        else
                            assignin('base', sprintf('%s_%s',TabName{i},OptionalHeadings{hgp}),eval(OptionalHeadings{hgp}))
                        end
                
                   

                end
            end
            %%
            
            
   

    [TraceElements, Trace_Labels] = reorderElements_Rows(SpreadsheetName, TabName{i}, DesiredDataName{i}, targetStrings_Trace,'FirstTraceIsotope','LastTraceIsotope'); 


    assignin('base', (TabName{i}),sumMgNumNorm_PT(MajorElements,targetStrings_Majors,ElementIndicies4Target_Sum,AcceptableTotalRange));   
    assignin('base', [TabName{i},'_Trace'],TraceElements);    
    assignin('base', [TabName{i},'_Colors_FILL'],Major_Colors_Fill);  
    assignin('base', [TabName{i},'_Colors_LINE'],Major_Colors_Line); 
    assignin('base', [TabName{i},'_Labels'],Major_Labels);  
    assignin('base', [TabName{i},'_Markers'],Markers);  
    assignin('base', [TabName{i},'_Regions'],Regions); 
    assignin('base', [TabName{i},'_Sizes'],Sizes); 

%     assignin('base', [TabName{i},'_Lat'],Lat);
%     assignin('base', [TabName{i},'_Long'],Long);
%     assignin('base', [TabName{i},'_Samples'],Samples); 
%     assignin('base', [TabName{i},'_SPREADINGRATE'],Samples);    
%     assignin('base', [TabName{i},'_DEPTH'],Samples); 
%     assignin('base', [TabName{i},'_References'],Samples); 
%     assignin('base', [TabName{i},'_Info'],Samples);
%     assignin('base', [TabName{i},'_Expt'],Samples);
%     assignin('base', [TabName{i},'_Type'],Samples);
%     assignin('base', [TabName{i},'_F'],Samples);
%     assignin('base', [TabName{i},'_Phases'],Samples);
    
    %Calculate Tormey components of all the data 
    assignin('base', [TabName{i},'_Tormey'],TormeyProjection(MajorElements,targetStrings_Majors,targetStrings_Majors_Tormey_Indicies));
    
    [Isotopes, Isotope_Labels] = reorderElements_Rows(SpreadsheetName, TabName{i}, DesiredDataName{i}, targetStrings_Isotopes,'FirstTraceIsotope','LastTraceIsotope'); 
    assignin('base', [TabName{i},'_Isotopes'],Isotopes);   

    %Calculate Eu anomaly
    EuCol = find(strcmp(targetStrings_Trace,'Eu'));
    SmCol = find(strcmp(targetStrings_Trace,'Sm'));
    GdCol = find(strcmp(targetStrings_Trace,'Gd'));

    clear DataRatios
    for gg = 1:size(ElementRatios,1)
        DataRatios(:,gg) = TraceElements(:,ElementRatiosIndex(gg,1)) ./TraceElements(:,ElementRatiosIndex(gg,2)); 
        DataRatios(:,21) = 2.*(TraceElements(:,EuCol)./TraceElements4Normalization_PUM(EuCol))./((TraceElements(:,SmCol)./TraceElements4Normalization_PUM(SmCol))+(TraceElements(:,GdCol)./TraceElements4Normalization_PUM(GdCol))); 
        assignin('base',sprintf('%s_DataRatios',TabName{i}), DataRatios); 
    end

   if isempty(Sizes)==1
    Sizes = Markers;

    for llsw = 1:size(Markers,1)
        Sizes{llsw,1}='10'; 
    end
   end

    
    runningTrace = [runningTrace; TraceElements];
    runningMajors = [runningMajors; sumMgNumNorm_PT(MajorElements,targetStrings_Majors,ElementIndicies4Target_Sum,AcceptableTotalRange)];
    runningMajors_Unnorm = [runningMajors_Unnorm; MajorElements]; 
    
    runningLabels = [runningLabels; Major_Labels];
    runningTormey = [runningTormey; TormeyProjection(MajorElements,targetStrings_Majors,targetStrings_Majors_Tormey_Indicies)];
    runningColors_FILL = [runningColors_FILL; Major_Colors_Fill];
    runningColors_LINE = [runningColors_LINE; Major_Colors_Line];
    
    runningLATLONG = [runningLATLONG; str2double([Lat Long])];
    runningIsotopes = [runningIsotopes; Isotopes];
    runningTraceRatios = [runningTraceRatios; DataRatios];
    runningMarkers = [runningMarkers; Markers];
    runningRegions = [runningRegions; Regions];
    runningSamples = [runningSamples; Samples];
    runningSizes = [runningSizes; Sizes];
    
    runningINFO = [runningINFO; Info];
    runningPHASES = [runningPHASES; Phases];
    runningF = [runningF; F];
    runningEXPT = [runningEXPT; Expt];
    runningTYPE = [runningTYPE; Type];
    runningReferences = [runningReferences; References];
    
    runningDepth = [runningDepth; DEPTH];
    runningSprRate = [runningSprRate; SPREADINGRATE];
 
    
    C    = cell(size(Major_Labels,1),1);
    C(:) = TabName(i);
    runningTabNames=[runningTabNames; C];
    
    

     D    = cell(size(Major_Labels,1),1);
     D(:) = {DesiredDataName{i}};

    runningDataNames=[runningDataNames;D];
    
    
    
end


runningSprRate = str2double(runningSprRate);
runningDepth = str2double(runningDepth);



ElementRatios{21,1}='Eu';
ElementRatios{21,2}='Eu*';
for kk = 1:size(ElementRatios,1)
    RatioLabels{kk}=sprintf('%s/%s',ElementRatios{kk,1}, ElementRatios{kk,2});
end

clear DataRatios
    for gg = 1:size(ElementRatios,1)
        DataRatios(:,gg) = TraceElements4Normalization_PUM(:,ElementRatiosIndex(gg,1)) ./TraceElements4Normalization_PUM(:,ElementRatiosIndex(gg,2)); 
        DataRatios(:,21) = 2.*(TraceElements4Normalization_PUM(:,EuCol)./TraceElements4Normalization_PUM(EuCol))./((TraceElements4Normalization_PUM(:,SmCol)./TraceElements4Normalization_PUM(SmCol))+(TraceElements4Normalization_PUM(:,GdCol)./TraceElements4Normalization_PUM(GdCol))); 
    end
DataRatios_TraceElements4Normalization = DataRatios;  
    
    
data = runningMajors;
CombinedLabel = strcat(runningRegions,{'-'}, runningLabels); 
[UniqueLabels,UniqueLabels_Rows] = unique(CombinedLabel,'stable');

runningMajors_Unnorm(:,1:2)=[];
runningMajors_Unnorm(:,end+1)=nansum(runningMajors_Unnorm(:,1:12),2);

%% populates the plotting info if needed
for zz = UniqueLabels_Rows'
    i =find(ismember(CombinedLabel, CombinedLabel(zz)));

    runningSizes(i)=runningSizes(zz);
    runningColors_FILL(i)=runningColors_FILL(zz);
    runningColors_LINE(i)=runningColors_LINE(zz);
    runningMarkers(i)=runningMarkers(zz);
    
end


%%

LegendTableCurrent = table(CombinedLabel,...
        runningColors_FILL,runningColors_LINE,runningMarkers,runningSizes,runningTabNames,runningDataNames);
LegendTableCurrent=LegendTableCurrent([UniqueLabels_Rows],:);
LegendTableCurrent.Properties.VariableNames ={'CombinedLabel','COLOR_FILL','COLOR_LINE','MARKERS','SIZES','Tab','DataName'};     


disp('...')

play(Audio);
disp('Current Legend Details:')
LegendTableCurrent


    %from a tab named "Legend" with keyword "ReimportLegend"?
    prompt = sprintf('\n Do you want to: \n [1] Use current legend details \n [2] Reimport the legend (order and symbols) from an exisiting tab in the spreadsheet \n [3] Copy legend details to create new spreadsheet tab ?  \n  1/2/3:');
    inputprompt=input(prompt);
    if inputprompt==1
        disp('<strong>Okay! Keeping the legend as specified by the data tabs</strong>')
        
        
    else if inputprompt==2
            disp('<strong>Okay! Reimporting the legend from tab ''Legend'' (order, shapes, colors, sizes)</strong>')
            play(Audio);
            promptreponse = input(sprintf('\n Is ''%s'' the right tabname with new legend specifications? \n Press any key if yes, enter ''N'' to change:',NewLegendTab),'s');
            if strcmp(promptreponse,'N')
               NewLegendTab = input('Okay, what should it be?','s');
            else
               disp('<strong>Okay! Using that folder</strong>')
                
            end
            play(Audio);
            promptreponse = input(sprintf('\n Is ''%s'' the right Keyword for the new legend? \n Press any key if yes, enter ''N'' to change:',NewLegendTab_Dataname),'s');
            if strcmp(promptreponse,'N')
                 NewLegendTab_Dataname = input('Okay, what should it be?','s');
            else
                disp('<strong>Okay! Using that folder</strong>')
               
            end
            
            CCC_ImportNewLegendGOOD
            
            
            LegendTableCurrent = table(CombinedLabel,...
            runningColors_FILL,runningColors_LINE,runningMarkers,runningSizes,runningTabNames,runningDataNames);
            LegendTableCurrent=LegendTableCurrent([UniqueLabels_Rows],:);
            LegendTableCurrent.Properties.VariableNames ={'CombinedLabel','COLOR_FILL','COLOR_LINE','MARKERS','SIZES','Tab','DataName'};     

            
            disp('New Legend Details:')
            LegendTableCurrent

        else if inputprompt==3
                Legend2copy = table2cell(LegendTableCurrent);
                Legend2copy=[LegendTableCurrent.Properties.VariableNames; Legend2copy];
                KeywordColumn = cell(size(Legend2copy,1),1);
                KeywordColumn(2:end)={NewLegendTab_Dataname};
                Legend2copy = [Legend2copy KeywordColumn];
                mat2clip(Legend2copy)
                disp(sprintf('<strong>Okay! Copied legend to clipboard. \n Paste (control-V) into Excel in a new tab, perhaps named ''Legend''. \n Then reorder and specify new symbols. \n When ready, save spreadsheet, and rerun this code. \n Now ending program. </strong>'))
                endprogram=1;
                return
            end
        end
    end





clear LegendTable
%% Save data to a new excel table
%     LABEL	REGION	COLOR_FILL	COLOR_LINE	MARKERS	SIZES 
%     SAMPLE LAT	LONG
%     INFO
%     EXPT	F	PHASES	
%     TYPE	
    
 
    NewTable = table(runningTabNames, runningDataNames,runningRegions,runningLabels,CombinedLabel,...
        runningColors_FILL,runningColors_LINE,runningMarkers,str2double(runningSizes),...
        runningSamples,runningLATLONG(:,1),runningLATLONG(:,2),...
        runningDepth, runningSprRate, ...
        runningINFO,runningReferences,...
        runningEXPT,runningF,runningPHASES,runningTYPE,...
        runningMajors,...
        runningTrace,...
        runningIsotopes,...
        runningTraceRatios,...
        runningMajors_Unnorm);
 
    NewTable.Properties.VariableNames ={'TabName','DataName','Region','Label','CombinedRegionLabel', 'ColorFill','ColorLine','Markers','Sizes',...
        'Sample','Lat','Long','Depth_m','SpeadingRate','Info','Reference','Expt','F','Phases','Type',...
        'runningMajors','runningTrace','runningIsotopes','runningTraceRatios','runningMajors_Unnorm'};  
    
    NewElements = {'T_C' 'P_kbar' ...
        'SiO2norm'	'TiO2norm'	  'Al2O3norm' 'Cr2O3norm'	  'FeOnorm'	  'MnOnorm'	  'MgOnorm'	  'CaOnorm' 'Na2Onorm'   'K2Onorm' 'P2O5norm' 'NiOnorm' 'H2Onorm' 'total_norm'...
        'MgNum' 'NaKNum' 'CaOAl2O3wt' 'CaOAl2O3mol' 'Na2OFeO' 'K2OTiO2' 'OneMinusMgNum' 'Qtz' 'Plag' 'Oliv' 'Cpx' 'Ox' 'Or' 'Ap'};
    %NewTable = splitvars(NewTable,'runningMajors','NewVariableNames', matlab.lang.makeValidName(Elements));
    NewTable = splitvars(NewTable,'runningMajors','NewVariableNames', NewElements);
    
    NewTable = splitvars(NewTable,'runningTrace','NewVariableNames', targetStrings_Trace);
    NewTable = splitvars(NewTable,'runningIsotopes','NewVariableNames', targetStrings_Isotopes);
    NewRatioLabels = regexprep(RatioLabels,'/','');
    NewRatioLabels = regexprep(NewRatioLabels,'EuEu*','EuAnom');
    NewRatioLabels = regexprep(NewRatioLabels,'*','');
    NewTable = splitvars(NewTable,'runningTraceRatios','NewVariableNames', NewRatioLabels);
    
    Unnorm = {'SiO2or'	'TiO2or'	  'Al2O3or' 'Cr2O3or'	  'FeOor'	  'MnOor'	  'MgOor'	  'CaOor' 'Na2Oor'   'K2Oor' 'P2O5or' 'NiOor' 'H2Oor' 'Anh_total'};
    NewTable = splitvars(NewTable,'runningMajors_Unnorm','NewVariableNames', Unnorm);

 
   % Save 4 significant digits
   numericVars = find(varfun(@isnumeric,NewTable,'output','uniform'));
   NewTable(:,numericVars) = varfun(@(var) round(var, 4, 'significant'), NewTable(:,numericVars));
   %NewTable.Properties.VariableNames=regexprep(NewTable.Properties.VariableNames, 'Fun_', '');



%%





KeywordColumn = cell(size(CombinedLabel,1),1);
                KeywordColumn(:)={NewLegendTab_Dataname};
                            
LegendTable = table(CombinedLabel,...
        runningColors_FILL,runningColors_LINE,runningMarkers,runningSizes,KeywordColumn,...
        runningRegions,runningLabels,runningDataNames);
LegendTable=LegendTable([UniqueLabels_Rows],:);
LegendTable.Properties.VariableNames ={'CombinedLabel','COLOR_FILL','COLOR_LINE','MARKERS','SIZES','NewLegendTab_Dataname', 'REGION','LABEL','DataName'};     
