function AgeInfo= NewtonRaphsonPbAge(m)


%Newton Raphson parameters
XACC = 1e-6;
X1 = 1;
X2 = 6e9;
JMAX=1000;

lambda238 = log(2) / 4.47e9; 
lambda235 = log(2) / 0.707e9; 

testSlope = (1/137.88.*exp(lambda235.*X1-1)./exp(lambda238.*X1-1));

F = testSlope - m; 

if F < 0
    RT4BIS=X1;
    DX=X2-X1;
else
    RT4BIS=X2;
    DX=X1-X2;
end



for J = 1:JMAX
    DX=DX*.5;
    XMID=RT4BIS+DX;
 
 testSlope= (1/137.88.*exp(lambda235.*XMID-1)./exp(lambda238.*XMID-1));
 FMID = testSlope - m;

    if FMID < 0
        RT4BIS=XMID; 
    end
    

    if abs(FMID) < XACC ||  FMID == 0;
        RT4BIS=XMID; %SB: put this here to prevent errors occuring when the F is initially < 0.  
        break; 
    end
   
end




%
AgeInfo = [RT4BIS];
