function [probeData] = sumMgNumNorm_PT(probeData,ElementsIn,ElementIndicies4Target,AcceptableTotalRange)



% 3-SiO2	4 -TiO2	  5- Al2O3  6-Cr2O3	  7-FeO	  8-MnO	  9-MgO	  10-CaO	11-Na2O   12-K2O
% 13-P2O5 14-NiO 15-H2O 16-total
% 17-Mg# 18-NaK 19 - CaO/Al2O3 20 -
% CaO/Al2O3 moles 21: Na2O/FeO 22: K2O/TiO2 23:1-Mg#
% 24-Quartz 25-Plag 26-Olivine 27-Cpx 28-Oxides 29-Or 30-Ap
Elements = {'T(C)' 'P(kbars)' ...
    'SiO2'	'TiO2'	  'Al2O3' 'Cr2O3'	  'FeO'	  'MnO'	  'MgO'	  'CaO' 'Na2O'   'K2O' 'P2O5' 'NiO' 'H2O' 'total'...
    'Mg#' 'NaK#' 'CaO/Al2O3 wt%' 'CaO/Al2O3 moles' 'Na2O/FeO' 'K2O/TiO2' '1-Mg#' 'Qtz' 'Plag' 'Oliv' 'Cpx' 'Ox' 'Or' 'Ap'};



noData = find(ElementIndicies4Target==0);
ElementIndicies4Target(ElementIndicies4Target == 0) = max(ElementIndicies4Target);
probeData = probeData(:,ElementIndicies4Target);
%pads rows of NaNs for elements with missing data
probeData(:,noData)=[NaN];


%    %hydrous
%    datarange = [4:16];

%anhydrous
datarange = [3:14];

%Remove data with bad totals by setting them to NAN
RequiredTotalRange_Min = AcceptableTotalRange(1);
RequiredTotalRange_Max = AcceptableTotalRange(2);
TempTotal =  nansum(probeData(:,datarange),2); %%recalculates anhydrous total
[TempTotal_a]=find(TempTotal<RequiredTotalRange_Min | TempTotal>RequiredTotalRange_Max);
probeData(TempTotal_a,:) = NaN.*probeData(TempTotal_a,:);

%normalizes each row
for n=1:size(probeData,1)
        probeData(n,datarange) = 100*probeData(n,datarange)./nansum(probeData(n,datarange));
end


probeData(:,16) = nansum(probeData(:,datarange),2); %%recalculates total






%calculates the Mg#
probeData(:,17) = (probeData(:,9)./40.311)./((probeData(:,9)./40.311) + (probeData(:,7)./71.846));

%NaK#
probeData(:,18) =  nansum(probeData(:,11:12),2)./nansum(probeData(:,10:12),2);

%CaO Al2O3 ratio
probeData(:,19) =  probeData(:,10)./probeData(:,5);

%Ca Al ratio
CaMoles = probeData(:,10)./56.078;
AlMoles = probeData(:,5 )./101.964.*2;
probeData(:,20) =  CaMoles./AlMoles;

%Na2O/FeO Ratio
probeData(:,21) =  probeData(:,11)./probeData(:,7);

%K2O/TiO2 ratio
probeData(:,22) =  probeData(:,12)./probeData(:,4);

%1-Mg#
probeData(:,23) = 1-probeData(:,17);


TormeyTargetElements ={ 'SiO2'	'TiO2' 'Al2O3'	'Cr2O3'  'FeO'	'MnO'	'MgO' 'CaO'  'Na2O'	'K2O' 'P2O5' 'Fe2O3'};
% [A,ElementIndicies4Target] = ismember(Elements, ElementsIn);
[A,Tormey_Indicies] = ismember(TormeyTargetElements, Elements);
probeData(:,24:30) = TormeyProjection(probeData,Elements,Tormey_Indicies);

end



