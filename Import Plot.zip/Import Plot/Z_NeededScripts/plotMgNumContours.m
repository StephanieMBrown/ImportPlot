function [  ] = plotMgNumContours(xvalueText,yvalueText, Xrange,Yrange,MgNum_all)
lightgrey = [0.90    0.90    0.90];
%subplot(3,1,2)
    %plot contours of Mg number
%     currentfigureaxes=gca;
%     Xrange = currentfigureaxes.XLim;
%     Yrange = currentfigureaxes.YLim;
    currentfigureaxes = [Xrange Yrange];
    FeOmoles=71.864;
    MgOmoles=40.311;

   
    
if strcmp(yvalueText,'FEO')==1 &&  strcmp(xvalueText,'MGO') ==1

    MgRange = Xrange;
        for MgNum=MgNum_all
        F=FeOmoles./MgOmoles.*(1-MgNum)./MgNum.*MgRange;
        hold on
        contours = plot(MgRange,F,'-','Color','k','handlevisibility','off');
        if MgNum==.5 || MgNum== 0.72
            %MgNum
            contours2 = plot(MgRange,F,'r-');
            uistack(contours2,'bottom');
        end
        
        uistack(contours,'bottom');
        end
   
elseif strcmp(yvalueText,'MGO')==1 &&  strcmp(xvalueText,'FEO') ==1 

    MgRange = Yrange;
        for MgNum =MgNum_all
        F=FeOmoles./MgOmoles.*(1-MgNum)./MgNum.*MgRange;
        hold on
        contours = plot(F,MgRange,'-','Color','k','handlevisibility','off');
  
        
        text(6,interp1(F,MgRange,6),num2str(MgNum*100),'HorizontalAlignment','center','VerticalAlignment', 'bottom','FontName','Times New Roman')
        uistack(contours,'bottom');
        end    
              
end      

axis(currentfigureaxes)
end

