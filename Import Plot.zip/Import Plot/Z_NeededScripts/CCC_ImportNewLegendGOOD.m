
[xlsNumbers, xlsText,xlsRAW] = xlsread(SpreadsheetName, NewLegendTab);
xlsRAW_strings=cellfun(@num2str,xlsRAW,'un',0);

[a,b]=find(ismember(xlsRAW_strings, NewLegendTab_Dataname,'legacy'));
if any(b)
    DRow=a;
    DColumn=b(1);
    
else
    DRow=[];
    DColumn=[];
end

%[LabelRow,LabelColumn]= find(strcmp(xlsRAW_strings,'LABEL')==1);
%[REGIONRow,REGIONColumn]= find(strcmp(xlsRAW_strings(LabelRow,:),'REGION')==1);

[CombinedRow,CombinedColumn]= find(strcmp(xlsRAW_strings,'CombinedLabel')==1);

[ColorRow_Fill,ColorColumn_Fill]= find(strcmp(xlsRAW_strings(CombinedRow,:),'COLOR_FILL')==1);
[ColorRow_Line,ColorColumn_Line]= find(strcmp(xlsRAW_strings(CombinedRow,:),'COLOR_LINE')==1);

[SizeRow,SizeColumn]= find(strcmp(xlsRAW_strings(CombinedRow,:),'SIZES')==1);
[MARKERRow,MARKERColumn]= find(strcmp(xlsRAW_strings(CombinedRow,:),'MARKERS')==1);




%DLabels = (xlsRAW_strings(unique(DRow),LabelColumn));
%DREGION= xlsRAW_strings(unique(DRow),REGIONColumn);

DCombined = xlsRAW_strings(unique(DRow),CombinedColumn);
DColors_Fill = xlsRAW_strings(unique(DRow),ColorColumn_Fill);
DColors_Line = xlsRAW_strings(unique(DRow),ColorColumn_Line);
DMARKERS = xlsRAW_strings(unique(DRow),MARKERColumn);
DSizes= xlsRAW_strings(unique(DRow),SizeColumn);

NewCombinedLabel = DCombined; %strcat(DREGION,{'-'}, DLabels);
[New_UniqueLabels,New_UniqueLabels_Rows] = unique(NewCombinedLabel,'stable');

CheckImport=setdiff(NewCombinedLabel,UniqueLabels);


if isempty(CheckImport)==1
    
    [a,NewOrder]=ismember(New_UniqueLabels,UniqueLabels);
    UniqueLabels=UniqueLabels(NewOrder);
    UniqueLabels_Rows = UniqueLabels_Rows(NewOrder);
    
    runningMarkers(UniqueLabels_Rows)=DMARKERS;
    runningColors_LINE(UniqueLabels_Rows)=DColors_Line;
    runningColors_FILL(UniqueLabels_Rows)=DColors_Fill;
    runningSizes(UniqueLabels_Rows) =DSizes;
    
    
    %populate the plotting info if needed
    for zz = UniqueLabels_Rows'
        i =find(ismember(CombinedLabel, CombinedLabel(zz)));
        
        runningSizes(i)=runningSizes(zz);
        runningColors_FILL(i)=runningColors_FILL(zz);
        runningColors_LINE(i)=runningColors_LINE(zz);
        runningMarkers(i)=runningMarkers(zz);
        
    end
    
    
    
    
else
    fprintf('<strong>ERROR with reimporting legend; there are not same number of unique entries. \n Check spreadsheet. \n Using previous labels. </strong>\n')
    
    return
end
