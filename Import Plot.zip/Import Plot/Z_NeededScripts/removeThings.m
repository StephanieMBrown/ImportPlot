[xlsNumbers, xlsText, xlsraw] = xlsread('Villiger2007', 'Sheet1');

xlsraw = cellfun(@num2str, xlsraw, 'UniformOutput', false);

% test = regexprep((xlsraw), '�([^�]*)$', '');
% test = regexprep((test), 'NaN', '');
% 
% mat2clip(test)
% test = regexprep(test, '+([^+]*)$', '');
% mat2clip(test)


test = regexprep(xlsraw, '(?<=\()[^)]*(?=\))', '');
pattern = '(\(|\))'; 
test = regexprep(test, pattern, '');
mat2clip(test)
