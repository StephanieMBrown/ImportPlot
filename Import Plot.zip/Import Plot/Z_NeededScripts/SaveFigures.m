%Specify if you would the figures to automatically save. You will likely
%need to modify the figures and then ressave anyways...
play(Audio);

appendtext = input('If desired, enter a string to append to each saved figure title:','s');
if isempty(appendtext) ==1
    appendtext='';
end


anyclose = input('Do you want to save all open figures? Y/N [Y]: ','s');
if strcmp(anyclose,'Y')==1
    disp('Okay, will save all open figures')
else
    Figs2Keep = input('Which figure numbers do you want to save? (e.g., ''1 20'') ','s');
    eval(['cab ' Figs2Keep]); 
end

subfolderHere =[ImportPlotMasterFolder '/' subfolder '/'];


typesave = input('PDF, EPS, JPG?: ','s');
if strcmp(typesave,'PDF')==1
    savefigsPDF(appendtext,subfolderHere)
else if strcmp(typesave,'JPG')==1
        savefigsJPG(appendtext,subfolderHere)
    else if strcmp(typesave,'EPS')==1
            savefigs(appendtext,subfolderHere)
        else
            'Problem. Did not save. Try again'

        end
    end
end


