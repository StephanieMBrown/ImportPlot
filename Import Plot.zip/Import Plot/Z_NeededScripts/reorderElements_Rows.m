function [newlyOrderedElements, DLabels, DColors_Fill, DColors_Line,DLAT,DLONG,DREGION,DMARKERS,DSAMPLES,DINFO,DPHASES,DF,DEXPT,DTYPE,DSizes,DReferences,Depth,SpRate] = reorderElements_Rows(SpreadsheetName, TabName, targetDataLabel, targetElements,FirstElement,LastElement)

%orderElements('TraceElements', 'Niu2009', Elements)
%reads in data in the wrong order and reorders it
%%
%
%  targetDataLabel = 'PlotOn';
%  SpreadsheetName = SpreadsheetName; %XLSFileName;
%  TabName= 'UTh_georock'; %'Gakkel'; %char(sheetLabels(i));
% %
% %  targetElements = targetStrings_Trace;
% % FirstElement = 'FirstTrace';
% % LastElement = 'LastTrace';
% %
% %
%  targetStrings_Majors = {'Temp','Pressure','SiO2','TiO2','Al2O3', 'Cr2O3','FeO','MnO','MgO','CaO','Na2O','K2O','P2O5','NiO','H2O'};
%  targetElements = targetStrings_Majors;
% FirstElement = 'FirstMajor';
% LastElement = 'LastMajor';



targetElements = upper(targetElements);



[xlsNumbers, xlsText,xlsRAW] = xlsread(SpreadsheetName, TabName);
[ElementRow,ElementColumn]= find(strcmp(xlsRAW,FirstElement)==1);
[LastElementRow,LastElementColumn]= find(strcmp(xlsRAW,LastElement)==1);
Elements = xlsRAW(ElementRow+1, ElementColumn:LastElementColumn);

originalElements = Elements;
Elements = regexprep(Elements,' ','');
Elements = upper(Elements);


%mat2clip(Elements)


%Finds MELTS
xlsRAW_strings=cellfun(@num2str,xlsRAW,'un',0);


%xlsRAW_strings=upper(xlsRAW_strings);
%[DRow,DColumn]= find(~cellfun(@isempty,regexp(xlsRAW_strings,targetDataLabel)) ==1);
[a,b]=find(ismember(xlsRAW_strings, targetDataLabel,'legacy'));
if any(b)
    DRow=a;
    DColumn=b(1);
    
else
    DRow=[];
    DColumn=[];
end




[LabelRow,LabelColumn]= find(strcmp(xlsRAW_strings,'LABEL')==1);
[ColorRow_Fill,ColorColumn_Fill]= find(strcmp(xlsRAW_strings,'COLOR_FILL')==1);
[ColorRow_Line,ColorColumn_Line]= find(strcmp(xlsRAW_strings,'COLOR_LINE')==1);

[LATRow,LATColumn]= find(strcmp(xlsRAW_strings(LabelRow,:),'LAT')==1);
[LONGRow,LONGColumn]= find(strcmp(xlsRAW_strings(LabelRow,:),'LONG')==1);
[REGIONRow,REGIONColumn]= find(strcmp(xlsRAW_strings(LabelRow,:),'REGION')==1);
[MARKERRow,MARKERColumn]= find(strcmp(xlsRAW_strings(LabelRow,:),'MARKERS')==1);
[SAMPLERow,SAMPLEColumn]= find(strcmp(xlsRAW_strings(LabelRow,:),'SAMPLE')==1);

[INFORow,INFOColumn]= find(strcmp(xlsRAW_strings(LabelRow,:),'INFO')==1);
[PHASESRow,PHASESColumn]= find(strcmp(xlsRAW_strings(LabelRow,:),'PHASES')==1);
[FRow,FColumn]= find(strcmp(xlsRAW_strings(LabelRow,:),'F')==1);
[EXPTRow,EXPTColumn]= find(strcmp(xlsRAW_strings(LabelRow,:),'EXPT')==1);
[TYPERow,TYPEColumn]= find(strcmp(xlsRAW_strings(LabelRow,:),'TYPE')==1);
[SizeRow,SizeColumn]= find(strcmp(xlsRAW_strings(LabelRow,:),'SIZES')==1);
[REFERENCERow,REFERENCEColumn]= find(strcmp(xlsRAW_strings(LabelRow,:),'REFERENCE')==1);


[DepthRow,DepthColumn]= find(strcmp(xlsRAW_strings(LabelRow,:),'DEPTH_m')==1);
[SpRateRow,SpRateColumn]= find(strcmp(xlsRAW_strings(LabelRow,:),'SpRate_x')==1);


DLabels = (xlsRAW_strings(unique(DRow),LabelColumn));
DColors_Fill = xlsRAW_strings(unique(DRow),ColorColumn_Fill);
DColors_Line = xlsRAW_strings(unique(DRow),ColorColumn_Line);


DLAT= xlsRAW_strings(unique(DRow),LATColumn);
DLONG = xlsRAW_strings(unique(DRow),LONGColumn);
DREGION= xlsRAW_strings(unique(DRow),REGIONColumn);
DMARKERS = xlsRAW_strings(unique(DRow),MARKERColumn);
DSAMPLES = xlsRAW_strings(unique(DRow),SAMPLEColumn);
DINFO = xlsRAW_strings(unique(DRow),INFOColumn);
DPHASES = xlsRAW_strings(unique(DRow),PHASESColumn);
DEXPT = xlsRAW_strings(unique(DRow),EXPTColumn);
DTYPE = xlsRAW_strings(unique(DRow),TYPEColumn);
DReferences= xlsRAW_strings(unique(DRow),REFERENCEColumn);


DSizes= xlsRAW_strings(unique(DRow),SizeColumn);
DF = (xlsRAW_strings(unique(DRow),FColumn));

Depth= (xlsRAW_strings(unique(DRow),DepthColumn));

SpRate= (xlsRAW_strings(unique(DRow),SpRateColumn));


[WGPRow,WGPColumn]=find(strcmp(xlsRAW_strings,'Garnet%')==1);

if isempty(WGPRow)==1
    WGP=[];
else
    WGP = cell2mat(xlsRAW(DRow, WGPColumn));
end



% test = xlsRAW(DRow,ElementColumn:LastElementColumn);
% % numind = cellfun(@isnumeric, test);
% % test(numind) = {'0'};
% DData = cell2mat(test);

DData = (xlsRAW(DRow,ElementColumn:LastElementColumn));
i1 = cellfun(@ischar,DData);
sz = cellfun('size',DData(~i1),2);

DData(i1) = {nan(1,sz(1))};
DData = cell2mat(DData);

%this code finds K in ppm and converts
Kcolumn = find(strcmp('K',Elements));
K2Ocolumn = find(strcmp('K2O',Elements));
if any(Kcolumn)&&any(K2Ocolumn)
    Kcolumn_2K2O = DData(:,Kcolumn).*0.83016*10^-4; %converts K in ppm to K2O in wt%
    K2O_Original = DData(:,K2Ocolumn);
    
    for h = 1:size(K2O_Original,1)
        if isnan(K2O_Original(h))==1
            K2O_Merged(h)=Kcolumn_2K2O(h);
        else
            K2O_Merged(h)=K2O_Original(h);
        end
    end
    DData(:,K2Ocolumn)=K2O_Merged';
end





Fe2O3Tcolumn= find(strcmp('FE2O3T',Elements));
Fe2O3column = find(strcmp('FE2O3',Elements));
FeOTcolumn = find(strcmp('FEOT',Elements));
FeOcolumn = find(strcmp('FEO',Elements));
if isempty(FeOcolumn)
    FeOcolumn = NaN;
end
if isempty(FeOTcolumn)
    FeOTcolumn = NaN;
end
if isempty(Fe2O3column)
    Fe2O3column = NaN;
end
if isempty(Fe2O3Tcolumn)
    Fe2O3Tcolumn = NaN;
end
    
    FeO_Options=[Fe2O3Tcolumn Fe2O3column FeOTcolumn FeOcolumn];


if any(isnan(FeO_Options)) ==1
    zerosCol = size(DData,2)+1; 
    if isnan(FeOcolumn)
        FeOcolumn = zerosCol;
    end
    
    if isnan(FeOTcolumn)
        FeOTcolumn = zerosCol;
    end
    if isnan(Fe2O3column)
        Fe2O3column = zerosCol;
    end
    if isnan(Fe2O3Tcolumn)

        Fe2O3Tcolumn = zerosCol;
    end
    
    %Tack on an extra column of zeros to DData
    DData(:,zerosCol) = nan.*ones(size(size(DData,1),1));
    
end


FeO_Options=[FeOTcolumn Fe2O3Tcolumn FeOcolumn Fe2O3column];
FeOALLDATA = DData(:,FeO_Options); 

FeOALLDATA(isnan(FeOALLDATA))=0; 




FeOTdata = FeOALLDATA(:,1);
Fe2O3Tdata = 0.899.*FeOALLDATA(:,2);
FeOFe2O3SUMdata = FeOALLDATA(:,3)+0.899.*FeOALLDATA(:,4);
FeOALLDATA = [FeOTdata Fe2O3Tdata FeOFe2O3SUMdata];

FeO_Total_Amalag = max(FeOALLDATA,[],2);



[A,ElementIndicies4Target] = ismember(targetElements, Elements);
noData = find(ElementIndicies4Target==0);

ElementIndicies4Target(ElementIndicies4Target == 0) = max(ElementIndicies4Target);

% targetElements
% Elements
% ElementIndicies4Target
% size(DData)
if any(ElementIndicies4Target)==1
    newlyOrderedElements = DData(:,ElementIndicies4Target);
    
    %pads rows of NaNs for elements with missing data
    newlyOrderedElements(:,noData)=[NaN];
    
    
    FeOIndex= find(strcmp('FEO',targetElements));
    if any(FeOIndex)==1
        newlyOrderedElements(:,FeOIndex)=FeO_Total_Amalag;
    end
    
else
    newlyOrderedElements=NaN.*ones(size(DData,1), size(targetElements,2)); 
end



% DataLabels_BC = regexprep(xlsText(unique(Row_BC),Column_BC),'BC_','');
% Data_BC = xlsNumbers(ElementRow+1:LastElementRow-1,Column_BC);
% Colors_BC = xlsText(unique(Row_BC-1),Column_BC);
end

