% Matlab requires colors in fractions of a percent RGB units. 
% illustrator uses decimal units out of 255

%Colors for plotting in RGB units
    %names from here:
    %https://en.wikipedia.org/wiki/List_of_colors:_A%E2%80%93F

    %http://colorbrewer2.org/#type=sequential&scheme=Greys&n=4

    
    
   BurnishedBrownSky = [.47 .71 1]; 
   cottoncandy = [ 1 .75 .85]; 
   
    garnetRed = [180 5 10]./255;
    plagBlue = [198 255 255]./255;
    
    goodLightBrown= [220,200,163]./256;
         goodBrown= [168,117,87]./256;
         goodSalmon= [255,135,130]./256;
         
         
    goodblue = [18,98,178]./256;
 goodBrown= [168,117,87]./256;
    deepOrange = [0.9100    0.4100    0.1700]; %[247 144 30];%
    bitterLime = [.39 .55 .07];
    antiquebronze = [.4 .36 .12];
    fireEngineRed = [.81 .13 .16];
    candyAppleRed = [1	.03	0];
    bananaYellow = [1 .88	.21];
    androidgreen = [.64	.78	.22];
    articlime = [.82	1	.08];
    dollarbill = [.52	.73	.40];
    chartruese = [.87 1 0];
    frenchlime  = [.62	.99	.22];
    olivinegreen = [.60 .725 .415];
    coffee= [.44 .31 .22];
    classicrose = [.98 .80 .91];
    airsuperiorityblue= [.45 .63 .76];
    cadmiumgreen = [0 .42 .24];
    batterychargedblue = [.11 .67 .84];
    celadonblue = [0 .48 .65];
    babyblueeyes=[.63 .79 .95];
   azure = [0 .50 1]; 
   bittersweetShimmer = [.75 .31 .32]; 
   FrenchBlueSky = [.47 .71 1]; 
   FrenchBlue = [0 .45 .73]; 
   FrenchRose = [.96 .29 .54]; 
    
    Aureolin=[.99 .93 0];
    CadmiumYellow = [1 .96 0];%
    corn = [.98 .93 .36];
    CadmiumRed = [.89 0 .13]; 
    fuschia = [1 0 1]; 
    
    
   BurnishedBrown=[.63	.48	.45];

    white = [1 1 1];
    grey9 = [0.90    0.90    0.90];
    grey85 = [0.85   0.85   0.85];
    grey8 = [0.80    0.80    0.80];
    grey7 = [0.700    0.700    0.700];
        grey65 = [0.65    0.65    0.65];
    grey6 = [0.600    0.600    0.600];
    grey55 = [0.55    0.55   0.55];
    grey5 = [0.500    0.500    0.500];
    grey4 = [0.400    0.400    0.400];
    grey3 = [0.300    0.300    0.300];
    grey2 = [0.200    0.200    0.200];
    grey1 = [0.100    0.100    0.100];
    black =	[0 0 0];
    
yellow = [1 1 0];
magenta = [1 0 1];
cyan=	[0 1 1];
red=	[1 0 0];
green = [0 1 0];
blue = [0 0 1];


EgypitanBlue = [.06	.20	.65] ;
DarkCornflowerBlue = [.15 .26	.55] ;

Aero=[.49	.73	.91] ;

Cold1 = [0.2298057	0.298717966	0.753683153]; 
Cold2 = [0.596262162	0.726149107	0.999836203]; 
Cold3 = [0.969954137	0.694266682	0.579375448]; 
Cold4 = [0.705673158	0.01555616	0.150232812]; 

Reds4_1 = [254,229,217]./256;
Reds4_2= [252,174,145]./256;
Reds4_3= [251,106,74]./256;
Reds4_4= [203,24,29]./256;


Blues4_1 = [239,243,255]./256;
Blues4_2= [189,215,231]./256;
Blues4_3= [107,174,214]./256;
Blues4_4= [33,113,181]./256;


Blues5_1 = [239,243,255]./256;
Blues5_2= [189,215,231]./256;
Blues5_3= [107,174,214]./256;
Blues5_4= [49,130,189]./256;
Blues5_5= [8,81,156]./256;

Reds5_1 = [254,229,217]./256;
Reds5_2 = [252,174,145]./256;
Reds5_3 = [251,106,74]./256;
Reds5_4 = [222,45,38]./256;
Reds5_5 = [165,15,21]./256;

darktan = [166 97 26]./256;
lightertan= [223,194,125]./256;




Blacks4_1 = [247,247,247]./256;
Blacks4_2 = [204,204,204]./256;
Blacks4_3 = [150,150,150]./256;
Blacks4_4 = [82,82,82]./256;
    

Blacks5_1 = [247,247,247]./256;
Blacks5_2 = [204,204,204]./256;
Blacks5_3 = [150,150,150]./256;
Blacks5_4 = [99,99,99]./256;
Blacks5_5 = [37,37,37]./256;


div_RdBu_7_01 =[178  24  43]./256; 
div_RdBu_7_02 =[239 138  98]./256;  
div_RdBu_7_03 =[253 219 199]./256;  
%div_RdBu_7_04 =[247 247 247 ]./256; 
div_RdBu_7_05 =[209 229 240 ]./256; 
div_RdBu_7_06 =[103 169 207]./256;  
div_RdBu_7_07 =[33 102 172]./256;  
